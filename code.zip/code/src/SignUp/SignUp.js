import React, { useState, useEffect } from "react";
import "./SignUp.css";
import axios from "axios";

const SignUp = () => {
  const [enteredFirstName, setEnteredFirstName] = useState("");
  const [enteredLastName, setEnteredLastName] = useState("");
  const [enteredUserName, setEnteredUserName] = useState("");
  const [enteredPassword, setEnteredPassword] = useState("");

  const [userMessage, setUserMessage] = useState("BLANK");
  const [passMessage, setPassMessage] = useState("BLANK");

  const submitHandler = (e) => {
    e.preventDefault();
    const postObj = {
      firstname: enteredFirstName,
      lastname: enteredLastName,
      username: enteredUserName,
      password: enteredPassword,
    };
    console.log("postObj", postObj);
    alert("Your sign up successful and username is: " + postObj.username);
    setEnteredFirstName("");
    setEnteredLastName("");
    setEnteredUserName("");
    setEnteredPassword("");
    setUserMessage("BLANK");
    setPassMessage("BLANK");
  };

  const firstnameHandler = (event) => {
    setEnteredFirstName(event.target.value);
  };

  const lastnameHandler = (event) => {
    setEnteredLastName(event.target.value);
  };

  const usernameHandler = (event) => {
    console.log("USerName", event.target.value);
    let ipUserName = event.target.value;
    if (ipUserName) {
      setEnteredUserName(ipUserName);
    }
  };
  useEffect(() => {
    console.log("userName", enteredUserName);
    if (enteredUserName) {
      axios
        .get(
          "https://www.reddit.com/api/username_available.json?user=" +
            enteredUserName
        )
        .then((res) => {
          console.log("res", res);
          if (res.data) {
            setUserMessage("OK");
          } else setUserMessage("NOT OK");
        })
        .catch((e) => {
          console.log("error", e);
        });
    }
  }, [enteredUserName]);

  useEffect(() => {
    let regex8 = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (enteredPassword) {
      if (enteredPassword.match(regex8)) {
        setPassMessage("OK");
      } else setPassMessage("NOT OK");
    }
  }, [enteredPassword]);
  const passwordHandler = (event) => {
    console.log("Password", event.target.value);
    setEnteredPassword(event.target.value);
  };

  return (
    <div className="sign-up__wrapper">
      <form onSubmit={submitHandler}>
        <div className="sign-up__formcontrol">
          <label>Firstname:</label>
          <input
            type="text"
            value={enteredFirstName}
            onChange={firstnameHandler}
            required
          />
        </div>
        <div className="sign-up__formcontrol">
          <label>Lastname:</label>
          <input
            type="text"
            value={enteredLastName}
            onChange={lastnameHandler}
            required
          />
        </div>
        <div className="sign-up__formcontrol">
          <label>Username:</label>
          <input
            type="text"
            value={enteredUserName}
            onChange={usernameHandler}
            required
          />
          <span className="check">{userMessage}</span>
        </div>
        <div className="sign-up__formcontrol">
          <label>Password:</label>
          <input
            type="password"
            value={enteredPassword}
            onChange={passwordHandler}
            required
          />
          <span className="check">{passMessage}</span>
        </div>
        <button className="perform-submit" type="submit">
          Sign Up
        </button>
      </form>
    </div>
  );
};
export default SignUp;
